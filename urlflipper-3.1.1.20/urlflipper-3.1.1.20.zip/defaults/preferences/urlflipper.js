pref("extensions.urlflipper@mozilla.ktechcomputing.com.description", "chrome://urlflipper/locale/urlflipper.properties");

pref("extensions.urlflipper.decr-modifiers", "accel,shift");
pref("extensions.urlflipper.decr-key", "VK_DOWN");
pref("extensions.urlflipper.incr-modifiers", "accel,shift");
pref("extensions.urlflipper.incr-key", "VK_UP");
pref("extensions.urlflipper.qdecr-modifiers", "accel,shift,alt");
pref("extensions.urlflipper.qdecr-key", "VK_DOWN");
pref("extensions.urlflipper.qincr-modifiers", "accel,shift,alt");
pref("extensions.urlflipper.qincr-key", "VK_UP");
pref("extensions.urlflipper.clear-modifiers", "accel,shift");
pref("extensions.urlflipper.clear-key", "C");
